#include <stdio.h>
#include <stdlib.h>
#include "fingerprint.h"



void *thread_Auto_Verify_Finger(void* no_parameter)
{
    (void)no_parameter;
    
    while(1)
    {
        Auto_Verify_Finger();
    }   
}

int main(void)
{    
    char  cmd_buf[5];
    char  ch;
   
    
    if(wiringPiSetupGpio() < 0) {    // using Broadcom GPIO pin mapping
        printf("Error: can not use Broadcom GPIO pin mapping  ! \n");
        return -1;
    }    
           
    pthread_mutex_init(&mut,NULL);
    ret = (pthread_create(&id, NULL, thread_Auto_Verify_Finger, NULL));
    while(ret != 0)
    {
        ret = (pthread_create(&id, NULL, thread_Auto_Verify_Finger, NULL));
    }
  
    Finger_Wait_Until_OK();
            
    while (1) 
    {                  
        printf("Please input command (CMD1-CMD6):");
        fgets(cmd_buf,sizeof(cmd_buf),stdin);        
        Analysis_PC_Command(cmd_buf);
        
        if( strchr(cmd_buf,'\n') == NULL )
        {
            while((ch=getchar())!='\n'&&ch!=EOF);  // clean stdin buffer before next fgets()    
        }        
        memset(cmd_buf, 0, sizeof(cmd_buf));
    }    
    serialClose(ser);
    return 0;
}

