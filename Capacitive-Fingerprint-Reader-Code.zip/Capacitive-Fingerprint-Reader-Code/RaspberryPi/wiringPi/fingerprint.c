#include "fingerprint.h"
#include <string.h>


			
uint8_t finger_TxBuf[8];			

int ser; 
uint8_t  finger_RxBuf[8];
uint16_t  finger_RxNum;
uint8_t     Finger_SleepFlag;

pthread_t    id;
pthread_mutex_t    mut; 
int  ret;
    
    

/***************************************************************************
* @brief      Send a byte of data to the serial port
* @param      temp : Data to send
****************************************************************************/
void  TxByte(uint8_t temp)
{	
	return   serialPutchar(ser, temp);  
}

/***************************************************************************
* @brief      send a command, and wait for the response of module
* @param      Scnt: The number of bytes to send
	      Rcnt: expect the number of bytes response module
	      Delay_ms: wait timeout
* @return     ACK_SUCCESS: success
  	      other: see the macro definition
****************************************************************************/
uint8_t TxAndRxCmd(uint8_t Scnt, uint8_t Rcnt, uint16_t Delay_ms)
{
	uint8_t  i, j, CheckSum;
    uint32_t before_time;        
    uint32_t after_time;
    uint8_t   overflow_Flag = 0;
    struct  timeval tv;
    uint16_t  Delay_s = 0;
    
       
 
    serialFlush(ser);      // clear serial RX buffer and wait until serial TX finished     
    
	TxByte(CMD_HEAD);			 
	CheckSum = 0;
	for (i = 0; i < Scnt; i++)
	{
		TxByte(finger_TxBuf[i]);		 
		CheckSum ^= finger_TxBuf[i];
	}	
	TxByte(CheckSum);
	TxByte(CMD_TAIL);  
               
    finger_RxNum = 0;  // clear  finger_RxNum  before next receive
    memset(finger_RxBuf,0,sizeof(finger_RxBuf));   ////////
	       
    if(Delay_ms >= 1000)
    {
        Delay_s = Delay_ms / 1000;
        Delay_ms = Delay_ms % 1000;
    }
           
    // Receive until time out
    gettimeofday(&tv,NULL);
    before_time = tv.tv_usec/1000;	 
    do
    {
        overflow_Flag = 0;
        
        if(serialDataAvail(ser))
        {
            finger_RxBuf[finger_RxNum++] = serialGetchar(ser);         
        }
                  
        gettimeofday(&tv,NULL);
        after_time = tv.tv_usec/1000;	
        if(before_time > after_time)   //if overflow (go back to zero)
        {
                gettimeofday(&tv,NULL);
                before_time = tv.tv_usec/1000;	// get time_before again
                overflow_Flag = 1;
        }
              
    } while (((finger_RxNum < Rcnt) && (after_time - before_time < Delay_ms)) || (overflow_Flag == 1));
    
    if(finger_RxNum < Rcnt && Delay_s > 0)
    {
        gettimeofday(&tv,NULL);
        before_time = tv.tv_sec;	 
        do
        {
            overflow_Flag = 0;
            
            if(serialDataAvail(ser))
            {
                finger_RxBuf[finger_RxNum++] = serialGetchar(ser);         
            }
                      
            gettimeofday(&tv,NULL);
            after_time = tv.tv_sec;	
            if(before_time > after_time)   //if overflow (go back to zero)
            {
                    gettimeofday(&tv,NULL);
                    before_time = tv.tv_sec;    // get time_before again
                    overflow_Flag = 1;
            }
                      
        } while (((finger_RxNum < Rcnt) && (after_time - before_time < Delay_s)) || (overflow_Flag == 1));      
    }
       
	if (finger_RxNum!= Rcnt)	return ACK_TIMEOUT;
	if (finger_RxBuf[0] != CMD_HEAD) 	   return ACK_FAIL;
	if (finger_RxBuf[Rcnt - 1] != CMD_TAIL)    return ACK_FAIL;
	if (finger_RxBuf[1] != (finger_TxBuf[0]))  return ACK_FAIL;

	CheckSum = 0;
	for (j = 1; j < finger_RxNum - 1; j++) CheckSum ^= finger_RxBuf[j];
	if (CheckSum != 0)   return ACK_FAIL; 	  

	return  ACK_SUCCESS;
}	 

/***************************************************************************
* @brief      Query the number of existing fingerprints
* @return     0xFF: error
  	        other: success, the value is the number of existing fingerprints
****************************************************************************/
uint8_t GetUserCount(void)
{
	uint8_t m;
	
	finger_TxBuf[0] = CMD_USER_CNT;
	finger_TxBuf[1] = 0;
	finger_TxBuf[2] = 0;
	finger_TxBuf[3] = 0;
	finger_TxBuf[4] = 0;	
	
	m = TxAndRxCmd(5, 8, 100);
			
	if (m == ACK_SUCCESS && finger_RxBuf[4] == ACK_SUCCESS)
	{
	    return finger_RxBuf[3];
	}
	else
	{
	 	return 0xFF;
	}
}

/***************************************************************************
* @brief      Get Compare Level
* @return     0xFF: error
  	      other: success, the value is compare level
****************************************************************************/
uint8_t GetcompareLevel(void)
{
	uint8_t m;
	
	finger_TxBuf[0] = CMD_COM_LEV;
	finger_TxBuf[1] = 0;
	finger_TxBuf[2] = 0;
	finger_TxBuf[3] = 1;
	finger_TxBuf[4] = 0;	
	
	m = TxAndRxCmd(5, 8, 100);
		
	if (m == ACK_SUCCESS && finger_RxBuf[4] == ACK_SUCCESS)
	{
	    return finger_RxBuf[3];
	}
	else
	{
	 	return 0xFF;
	}
}

/***************************************************************************
* @brief      Set Compare Level
* @param      temp: Compare Level,the default value is 5, can be set to 0-9, the bigger, the stricter
* @return     0xFF: error
  	      other: success, the value is compare level
****************************************************************************/
uint8_t SetcompareLevel(uint8_t temp)
{
	uint8_t m;
	
	finger_TxBuf[0] = CMD_COM_LEV;
	finger_TxBuf[1] = 0;
	finger_TxBuf[2] = temp;
	finger_TxBuf[3] = 0;
	finger_TxBuf[4] = 0;	
	
	m = TxAndRxCmd(5, 8, 100);
		
	if (m == ACK_SUCCESS && finger_RxBuf[4] == ACK_SUCCESS)
	{
	    return finger_RxBuf[3];
	}
	else
	{
	 	return 0xFF;
	}
}

/***************************************************************************
* @brief      Get the time that fingerprint collection wait timeout 
* @return     0xFF: error
  	      other: success, the value is the time that fingerprint collection wait timeout 
****************************************************************************/
uint8_t GetTimeOut(void)
{
	uint8_t m;
	
	finger_TxBuf[0] = CMD_TIMEOUT;
	finger_TxBuf[1] = 0;
	finger_TxBuf[2] = 0;
	finger_TxBuf[3] = 1;
	finger_TxBuf[4] = 0;	
	
	m = TxAndRxCmd(5, 8, 100);
		
	if (m == ACK_SUCCESS && finger_RxBuf[4] == ACK_SUCCESS)
	{
	    return finger_RxBuf[3];
	}
	else
	{
	 	return 0xFF;
	}
}

/***************************************************************************
* @brief      Register fingerprint
* @return     ACK_SUCCESS: success
  	      other: see the macro definition
****************************************************************************/
uint8_t AddUser(void)
{
	uint8_t m;
	
	m = GetUserCount();
	if (m >= USER_MAX_CNT)
		return ACK_FULL;

	finger_TxBuf[0] = CMD_ADD_1;
	finger_TxBuf[1] = 0;
	finger_TxBuf[2] = m +1;
	finger_TxBuf[3] = 3;
	finger_TxBuf[4] = 0;		
	m = TxAndRxCmd(5, 8, 5000);	
	if (m == ACK_SUCCESS && finger_RxBuf[4] == ACK_SUCCESS)
	{
		finger_TxBuf[0] = CMD_ADD_3;
		m = TxAndRxCmd(5, 8, 5000);
		if (m == ACK_SUCCESS && finger_RxBuf[4] == ACK_SUCCESS)
		{
			return ACK_SUCCESS;
		}
		else
		return ACK_FAIL;
	}
	else
		return ACK_FAIL;
}

/***************************************************************************
* @brief      Clear fingerprints
* @return     ACK_SUCCESS:  success
  	      ACK_FAIL:     error
****************************************************************************/
uint8_t  ClearAllUser(void)
{
 	uint8_t m;
	
	finger_TxBuf[0] = CMD_DEL_ALL;
	finger_TxBuf[1] = 0;
	finger_TxBuf[2] = 0;
	finger_TxBuf[3] = 0;
	finger_TxBuf[4] = 0;
	
	m = TxAndRxCmd(5, 8, 500);
	
	if (m == ACK_SUCCESS && finger_RxBuf[4] == ACK_SUCCESS)
	{	    
		return ACK_SUCCESS;
	}
	else
	{
		return ACK_FAIL;
	}
}

/***************************************************************************
* @brief      Check if user ID is between 1 and 3
* @return     TRUE
  	          FALSE
****************************************************************************/
uint8_t IsMasterUser(uint8_t UserID)
{
    if ((UserID == 1) || (UserID == 2) || (UserID == 3)) return TRUE;
			else  return FALSE;
}	 

/***************************************************************************
* @brief      Fingerprint matching
* @return     ACK_SUCCESS: success
  	      other: see the macro definition
****************************************************************************/
uint8_t VerifyUser(void)
{
	uint8_t m;
	
	finger_TxBuf[0] = CMD_MATCH;
	finger_TxBuf[1] = 0;
	finger_TxBuf[2] = 0;
	finger_TxBuf[3] = 0;
	finger_TxBuf[4] = 0;
	
	m = TxAndRxCmd(5, 8, 5000);
	
	if ((m == ACK_SUCCESS) && (IsMasterUser(finger_RxBuf[4]) == TRUE))
	{	
		 return ACK_SUCCESS;
	}
	else if(finger_RxBuf[4] == ACK_NO_USER)
	{
		return ACK_NO_USER;
	}
	else if(finger_RxBuf[4] == ACK_TIMEOUT)
	{
		return ACK_TIMEOUT;
	}
	else
	{
		return ACK_GO_OUT;   // The center of the fingerprint is out of alignment with sensor
	}
}

/***************************************************************************
* @brief      Wait until the fingerprint module works properly
****************************************************************************/
void Finger_Wait_Until_OK(void)
{	

    while((ser = serialOpen("/dev/ttyS0",19200)) < 0); 
     
    pinMode(WAKE_PIN, INPUT);
    pinMode(RST_PIN, OUTPUT);
    pullUpDnControl(WAKE_PIN, PUD_DOWN);
         
    digitalWrite(RST_PIN , LOW);
	msleep(250); 
    digitalWrite(RST_PIN , HIGH);
	msleep(250);  // Wait for module to start
	 // ERROR: Please ensure that the module power supply is 3.3V or 5V, 
	 // the serial line is correct, the baud rate defaults to 19200,
	 // and finally the power is switched off, and then power on again !
	while(SetcompareLevel(5) != 5)
	{
		sleep(1);    // sleep for 1s
		printf("***ERROR***: Please ensure that the module power supply is 3.3V or 5V, the serial line connection is correct, the baud rate defaults to 19200, and finally the power is switched off, and then power on again\n"); 
	}
   
	printf("*************** WaveShare Capacitive Fingerprint Reader Test ***************\n");
	printf("Compare Level:  5    (can be set to 0-9, the bigger, the stricter)\n"); 
	printf("Number of fingerprints already available:  %d\n",GetUserCount());
	printf(" Use the serial port to send the commands to operate the module:\n"); 
	printf("  CMD1 : Query the number of existing fingerprints\n"); 
	printf("  CMD2 : Add fingerprint  (Each entry needs to be read two times: \"beep\",put the finger on sensor, \"beep\", put up ,\"beep\", put on again)\n"); 
	printf("  CMD3 : Fingerprint matching  (Send the command, put your finger on sensor after \"beep\".Each time you send a command, module waits and matches once)\n"); 
	printf("  CMD4 : Clear fingerprints \n"); 
	printf("  CMD5 : Switch to sleep mode, you can use the finger Automatic wake-up function (In this state, only CMD6 is valid. When a finger is placed on the sensor,the module is awakened and the finger is matched, without sending commands to match each time. The CMD6 can be used to wake up) \n"); 
	printf("  CMD6 : Wake up and make all commands valid \n");
	printf("*************** WaveShare Capacitive Fingerprint Reader Test ***************\n");	
}

/***************************************************************************
* @brief     Analysis the command from PC terminal
****************************************************************************/
void Analysis_PC_Command(char * cmd_PC)
{	
    if((cmd_PC[0] == 'C')&&(cmd_PC[1] == 'M')&&(cmd_PC[2] == 'D'))
	{		
        switch(cmd_PC[3])
        {						
            case '1':
                if(Finger_SleepFlag == 1)  break;
                printf("Number of fingerprints already available:  %d  \n", GetUserCount());
                break;			
            case '2':
                if(Finger_SleepFlag == 1)  break;
                printf(" Add fingerprint  (Each entry needs to be read two times: \"beep\", put the finger on sensor, \"beep\", put up, \"beep\", put on again)\n"); 
                switch(AddUser())
                {
                    case ACK_SUCCESS:
                        printf("Fingerprint added successfully ! \n");
                        break;
                    
                    case ACK_FAIL: 			
                        printf("Failed: Please try to place the center of the fingerprint flat to sensor, or this fingerprint already exists ! \n");
                        break;
                    
                    case ACK_FULL:			
                        printf("Failed: The fingerprint library is full ! \n");
                        break;		
                }
                break;					
            case '3':
                if(Finger_SleepFlag == 1)  break;
                printf("Waiting Finger......Please try to place the center of the fingerprint flat to sensor ! \n");
                switch(VerifyUser())
                {
                    case ACK_SUCCESS:	
                        printf("Match successfully ! \n");
                        break;
                    case ACK_NO_USER:
                        printf("Failed: This fingerprint was not found in the library ! \n");
                        break;
                    case ACK_TIMEOUT:	
                        printf("Failed: Time out ! \n");
                        break;	
                    case ACK_GO_OUT:
                        printf("Failed: Please try to place the center of the fingerprint flat to sensor ! \n");
                        break;
                }
                break;				
            case '4':
                if(Finger_SleepFlag == 1)  break;
                ClearAllUser();
                printf("All fingerprints have been cleared ! \n");
                break;				
            case '5':
                if(Finger_SleepFlag == 1)  break;
                digitalWrite(RST_PIN , LOW);
                Finger_SleepFlag = 1;
                printf("Module has entered sleep mode: you can use the finger Automatic wake-up function, in this mode, only CMD6 is valid, send CMD6 to pull up the RST pin of module, so that the module exits sleep ! \n");	
                break;
            case '6':		
                if(pthread_mutex_lock(&mut) == 0)  
                {
                    digitalWrite(RST_PIN , HIGH);
                    msleep(250);  // Wait for module to start				
                    Finger_SleepFlag = 0;	                        
                    printf("The module is awake. All commands are valid ! \n");	
                    
                    pthread_mutex_unlock(&mut); 
                    break;                       
                }
                            
            default: break;
        }
    }
}

/***************************************************************************
* @brief  
     If you enter the sleep mode, then open the Automatic wake-up function of the finger,
     begin to check if the finger is pressed, and then start the module and match
****************************************************************************/
void Auto_Verify_Finger(void)
{
	if(digitalRead(WAKE_PIN) == HIGH)   // If you press your finger
	{	
        if(pthread_mutex_lock(&mut) == 0)      
        {
            msleep(10);			
            if(digitalRead(WAKE_PIN) == HIGH)   
            {
                digitalWrite(RST_PIN , HIGH);    // Pull up the RST to start the module and start matching the fingers
                msleep(250);	 // Wait for module to start
                        
                printf("Waiting Finger......Please try to place the center of the fingerprint flat to sensor ! \n");
                switch(VerifyUser())
                {
                    case ACK_SUCCESS:	
                        printf("Match successfully ! \n");
                        break;
                    case ACK_NO_USER:
                        printf("Failed: This fingerprint was not found in the library ! \n");
                        break;
                    case ACK_TIMEOUT:	
                        printf("Failed: Time out ! \n");
                        break;	
                    case ACK_GO_OUT:
                        printf("Failed: Please try to place the center of the fingerprint flat to sensor ! \n");
                        break;
                }
                
                //After the matching action is completed, drag RST down to sleep
                //and continue to wait for your fingers to press
                digitalWrite(RST_PIN , LOW);    
            }
            pthread_mutex_unlock(&mut);          
        }		
	}
}